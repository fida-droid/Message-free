# Ultra-Light Messaging App - Project Structure and Architecture

This document outlines the proposed project structure and architectural design for the Ultra-Light Messaging App MVP, focusing on Flutter for the frontend and Node.js with MQTT for the backend, including SMS fallback.

## 1. Overall Architecture

The application follows a client-server architecture with a strong emphasis on reliability and low data usage in challenging network conditions. The core components are:

- **Flutter Android App (Client):** Handles user interface, MQTT communication, local message storage, and SMS fallback logic.
- **Node.js Backend (Server):** Manages MQTT broker authentication, potentially handles OTP generation/verification, and acts as a bridge if needed (though direct MQTT is preferred for low latency).
- **Eclipse Mosquitto MQTT Broker:** The primary messaging transport, hosted on Oracle Cloud.
- **Firebase Realtime Database:** Used for message queuing and offline synchronization, ensuring message delivery even when clients are offline.
- **Android SMSManager:** The fallback mechanism for message delivery when data connectivity is poor or unavailable.

```mermaid
graph TD
    A[Flutter Android App] -->|MQTT v3.1.1 (QoS=1)| B(Eclipse Mosquitto MQTT Broker)
    B -->|Pub/Sub| A
    A -->|SMSManager (Fallback)| C[Recipient's Android App]
    C -->|Reads SMS| A
    B -->|Authentication| D[Node.js Backend]
    D -->|OTP Verification| A
    A -->|Offline Sync/Queue| E[Firebase Realtime Database]
    E -->|Message Queue| B
```

## 2. Flutter Android App Structure

The Flutter project will adhere to a clean, modular structure to ensure maintainability and scalability. The primary directories and their contents are:

```
ultra_light_messaging_app/
├── android/                # Android specific files (manifest, build.gradle, etc.)
├── lib/                    # Dart source code
│   ├── api/                # API clients (e.g., for OTP verification, if not handled by MQTT auth)
│   ├── auth/               # Authentication related logic (login, OTP, token management)
│   ├── config/             # Application constants, environment variables
│   ├── data/               # Data layer: repositories, local storage (Hive/SQFlite), Firebase integration
│   │   ├── models/         # Data models (e.g., Message, User)
│   │   └── services/       # Database services (Firebase, local DB)
│   ├── l10n/               # Localization files (arb files for English and Urdu)
│   ├── main.dart           # Main entry point of the Flutter application
│   ├── messaging/          # Core messaging logic (MQTT client, SMS handler, message processing)
│   │   ├── mqtt_service.dart # MQTT connection, publish, subscribe logic
│   │   ├── sms_service.dart  # SMS sending and receiving logic
│   │   └── message_queue.dart # Offline message queuing and retry logic
│   ├── routes/             # Route definitions and navigation logic
│   ├── screens/            # UI screens
│   │   ├── auth/           # Login/OTP screen
│   │   ├── chat/           # Chat List and Chat Screen
│   │   └── common/         # Reusable UI widgets
│   ├── services/           # Background services (e.g., flutter_background_service setup)
│   ├── utils/              # Utility functions (e.g., data compression, UUID generation)
│   └── widgets/            # Reusable application-specific widgets
├── assets/                 # Static assets (images, fonts, etc.)
│   └── i18n/               # JSON files for localization if not using arb
├── pubspec.yaml            # Project dependencies and metadata
├── README.md               # Project README
└── .gitignore              # Git ignore file
```

## 3. Node.js Backend Structure

The Node.js backend will be minimal, primarily focusing on MQTT broker authentication and potentially OTP generation/verification.

```
backend/
├── src/
│   ├── app.js              # Main application file (if a web server is needed)
│   ├── mqtt_auth.js        # MQTT authentication logic (e.g., checking tokens against Firebase)
│   └── utils/              # Utility functions
├── Dockerfile              # Docker configuration for deployment
├── package.json            # Project dependencies and scripts
├── .env                    # Environment variables
└── README.md               # Backend README
```

## 4. Key Architectural Decisions & Justifications

- **MQTT QoS 1:** Ensures at-least-once delivery, crucial for messaging reliability. Given the ultra-light requirement, QoS 2 (exactly-once) might introduce too much overhead.
- **Firebase Realtime Database for Offline Queue:** Provides real-time synchronization and offline capabilities out-of-the-box, simplifying the implementation of message queuing and ensuring data persistence even without active network connection.
- **Native Android SMSManager Fallback:** Direct use of `SMSManager` for sending and `BroadcastReceiver` for receiving SMS provides the most robust fallback mechanism, bypassing data network issues entirely.
- **Compressed JSON Payload:** Minimizes data usage per message, critical for 5-10 kbps connectivity. The example `{"f":"+92300...","t":"+92333...","m":"hello","id":"uuid"}` is a good starting point.
- **`flutter_background_service`:** Essential for maintaining the MQTT connection and processing messages in the background, ensuring a persistent messaging experience with minimal battery impact.
- **Oracle Cloud Free Tier:** Cost-effective hosting solution for the MQTT broker and Node.js backend, aligning with MVP constraints.

This structure provides a clear roadmap for development, ensuring all core requirements are addressed systematically.

# Ultra-Light Messaging App - Oracle Cloud Free Tier Deployment Guide

This guide provides step-by-step instructions for deploying the Node.js MQTT broker backend on Oracle Cloud Infrastructure (OCI) Free Tier. This setup ensures a cost-effective and scalable solution for the messaging app's backend.

## 1. Oracle Cloud Infrastructure (OCI) Account Setup

1.  **Sign Up for Free Tier:** Navigate to the [Oracle Cloud Free Tier page](https://www.oracle.com/cloud/free/) and sign up for a new account. You will need a credit card for verification, but you will not be charged unless you explicitly upgrade.
2.  **Login to OCI Console:** Once your account is active, log in to the [OCI Console](https://cloud.oracle.com/).

## 2. Create a Compute Instance (Virtual Machine)

1.  **Navigate to Compute:** In the OCI Console, open the navigation menu (☰) and go to **Compute** > **Instances**.
2.  **Create Instance:** Click **Create Instance**.
    *   **Name:** Provide a descriptive name (e.g., `ultra-light-mqtt-broker`).
    *   **Placement:** Choose an Availability Domain and Fault Domain. For Free Tier, usually only one option is available.
    *   **Image and Shape:**
        *   **Image:** Select `Oracle Linux 8` (or Ubuntu, if preferred). This guide assumes Oracle Linux.
        *   **Shape:** Choose an `Always Free` eligible shape, such as `VM.Standard.E2.1.Micro`.
    *   **Networking:**
        *   **Virtual Cloud Network (VCN):** Create a new VCN or use an existing one. Ensure it has an Internet Gateway.
        *   **Subnet:** Create a new subnet or use an existing public subnet.
        *   **Public IP Address:** Ensure 
a public IP address is assigned.
    *   **SSH Keys:** Generate a new SSH key pair or upload an existing public key. Save the private key securely.
3.  **Boot Volume:** Leave default settings.
4.  **Create:** Click **Create** to launch the instance.

## 3. Configure Network Security Group (Firewall Rules)

To allow MQTT traffic (port 1883) and SSH access (port 22) to your instance, you need to configure the Virtual Cloud Network (VCN) security list or Network Security Group (NSG).

1.  **Navigate to VCN:** Go to **Networking** > **Virtual Cloud Networks**.
2.  **Select your VCN:** Click on the VCN associated with your instance.
3.  **Security Lists/NSGs:** Click on the default security list or create a new Network Security Group.
4.  **Add Ingress Rules:** Add the following ingress rules:
    *   **SSH (Port 22):**
        *   **Source Type:** CIDR
        *   **Source CIDR:** `0.0.0.0/0` (Allows SSH from anywhere, restrict to your IP for better security)
        *   **IP Protocol:** TCP
        *   **Destination Port Range:** `22`
    *   **MQTT (Port 1883):**
        *   **Source Type:** CIDR
        *   **Source CIDR:** `0.0.0.0/0` (Allows MQTT from anywhere)
        *   **IP Protocol:** TCP
        *   **Destination Port Range:** `1883`

## 4. Connect to the Instance via SSH

1.  **Get Public IP:** From the instance details page, copy the **Public IP Address**.
2.  **SSH Command:** Open your terminal and use the following command, replacing `private_key_path` and `public_ip` with your details:
    ```bash
    ssh -i <private_key_path> opc@<public_ip>
    ```
    *   If you used Oracle Linux, the default user is `opc`.

## 5. Install Docker and Docker Compose

Once connected via SSH, install Docker and Docker Compose.

1.  **Update Packages:**
    ```bash
    sudo yum update -y
    ```
2.  **Install Docker:**
    ```bash
    sudo yum install docker-engine -y
    sudo systemctl start docker
    sudo systemctl enable docker
    sudo usermod -aG docker opc
    newgrp docker
    ```
3.  **Install Docker Compose:**
    ```bash
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.2.3/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    ```

## 6. Deploy the Node.js MQTT Backend

1.  **Transfer Backend Code:** Use `scp` to transfer your `backend` directory to the OCI instance.
    ```bash
    scp -i <private_key_path> -r /path/to/your/backend opc@<public_ip>:/home/opc/
    ```
2.  **Navigate to Backend Directory:**
    ```bash
    cd /home/opc/backend
    ```
3.  **Build and Run Docker Container:**
    ```bash
    docker build -t ultra-light-mqtt-backend .
    docker run -d --name mqtt-broker -p 1883:1883 ultra-light-mqtt-backend
    ```
    *   The `-d` flag runs the container in detached mode.
    *   `-p 1883:1883` maps the container's port 1883 to the host's port 1883.

## 7. Configure Firebase Realtime Database

1.  **Create Firebase Project:** Go to the [Firebase Console](https://console.firebase.google.com/) and create a new project.
2.  **Create Realtime Database:** In your Firebase project, navigate to **Realtime Database** and create a new database. Start in locked mode for security.
3.  **Service Account Key:**
    *   Go to **Project settings** > **Service accounts**.
    *   Click **Generate new private key** and download the `serviceAccountKey.json` file.
    *   **Important:** Securely transfer this file to your OCI instance (e.g., in the `backend` directory) and update `backend/src/app.js` to load it. Also, uncomment the Firebase Admin initialization code in `app.js`.
4.  **Database Rules:** Configure your Firebase Realtime Database rules to allow read/write access for authenticated users. For an MVP, you might start with:
    ```json
    {
      "rules": {
        "messages": {
          "$uid": {
            ".read": "auth != null && auth.uid == $uid",
            ".write": "auth != null && auth.uid == $uid"
          }
        }
      }
    }
    ```
    *   **Note:** This is a basic rule. For a full messaging app, you would need more sophisticated rules to handle chat permissions.

## 8. Update Flutter App with MQTT Broker Address and Firebase Config

1.  **MQTT Broker Address:** In `ultra_light_app/lib/messaging/mqtt_service.dart`, replace `your-mqtt-broker-address.com` with the **Public IP Address** of your OCI instance.
2.  **Firebase Configuration:** Add your Firebase configuration to your Flutter project. This typically involves:
    *   Adding `google-services.json` (for Android) to `android/app/`.
    *   Uncommenting `Firebase.initializeApp()` in `main.dart`.

Your backend is now deployed and configured on Oracle Cloud Free Tier. Remember to monitor your Free Tier usage to avoid unexpected charges if you decide to scale beyond the free limits.

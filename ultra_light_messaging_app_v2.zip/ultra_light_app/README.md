# Ultra-Light Messaging App

This is an MVP for an Ultra-Light Messaging App designed for areas with extremely poor 2G/3G connectivity. It prioritizes low data usage and provides an automatic SMS fallback mechanism when data connectivity is unreliable.

## Features

- **Ultra Low Data Usage:** Optimized for 5-10 kbps internet speeds.
- **MQTT Primary Transport:** Uses MQTT v3.1.1 with QoS=1 for efficient data messaging.
- **Automatic SMS Fallback:** If an MQTT message fails to get an acknowledgment within 5 seconds, the app automatically resends it via native SMS.
- **In-App SMS Display:** Incoming SMS messages are read by the app and displayed within the chat UI.
- **Offline Queue:** Messages are stored locally and sent automatically when connectivity is restored.
- **Simple UI:** Three screens only: Login/OTP, Chat List, and Chat Screen.
- **Connection Status:** Displays "Online via Data", "Online via SMS", or "Offline".
- **Message Status Indicators:** 'D' for Data, 'S' for SMS on sent messages.
- **Max Message Size:** 160 characters to fit in a single SMS.
- **Localization:** Supports English and Urdu.

## Architecture

- **Frontend:** Flutter app for Android (Android 8.0+).
- **Backend:** Node.js for MQTT broker authentication, running with Eclipse Mosquitto MQTT Broker.
- **Database:** Firebase Realtime Database for message queuing and offline sync.
- **SMS Fallback:** Native Android `SMSManager`.

## Project Structure

```
ultra_light_messaging_app/
├── android/                # Android specific files
├── lib/                    # Dart source code
│   ├── api/                
│   ├── auth/               # Login/OTP logic
│   ├── config/             
│   ├── data/               # Data models and services (Firebase, local storage)
│   │   ├── models/         
│   │   └── services/       
│   ├── l10n/               # Localization files
│   ├── main.dart           # Main entry point
│   ├── messaging/          # MQTT, SMS, and Message Management logic
│   │   ├── mqtt_service.dart 
│   │   ├── sms_service.dart  
│   │   └── message_manager.dart 
│   ├── routes/             
│   ├── screens/            # UI screens (Login, Chat List, Chat)
│   │   ├── auth/           
│   │   └── chat/           
│   ├── services/           # Background service setup
│   ├── utils/              
│   └── widgets/            
├── assets/                 # Static assets (localization files)
├── pubspec.yaml            # Project dependencies
├── README.md               # This file
└── .gitignore              
```

## Backend Setup

The backend consists of a Node.js application that handles MQTT authentication and an Eclipse Mosquitto MQTT Broker. A `Dockerfile` is provided for easy deployment.

**Refer to `oracle_cloud_deployment_guide.md` for detailed instructions on deploying the backend to Oracle Cloud Free Tier.**

## How Fallback Works

1.  **Primary Attempt (MQTT):** When a user sends a message, the app first attempts to send it via MQTT.
2.  **Acknowledgement Timeout:** A 5-second timer starts. If no acknowledgment (ACK) is received from the MQTT broker within this period, it indicates a potential data connectivity issue or broker unreachability.
3.  **SMS Fallback:** Upon timeout, the app automatically switches to sending the message via native Android SMS.
4.  **Recipient Handling:** The recipient's app, running in the background, listens for incoming SMS messages. If an SMS matches the expected compressed JSON format, it's parsed and displayed within the app's chat UI, indistinguishable from a data-sent message (except for the 'S' indicator).
5.  **Message Status:** The sender's app updates the message status to 'D' (Data) or 'S' (SMS) accordingly.

## Testing on 2G Speed

To simulate poor network conditions for testing the fallback mechanism:

1.  **Enable Developer Options:** On your Android device, go to `Settings > About phone` and tap `Build number` seven times to enable Developer Options.
2.  **Access Networking Settings:** Go to `Settings > System > Developer options`.
3.  **Throttle Network:** Look for options like `Network type` or `Cellular network type` and `Network speed`.
    *   Set `Network type` to `2G` or `EDGE`.
    *   Set `Network speed` to `20 kbps` (or lower, e.g., `5-10 kbps` if available).
    *   You might also find options for `Latency` (set to `1500ms`) and `Packet loss` (set to `5%`).
4.  **Test Scenario:**
    *   Ensure both sender and receiver apps are installed and logged in.
    *   Throttle the network on the sender's device.
    *   Send a message. Observe if it initially tries MQTT (no 'S' icon immediately) and then switches to SMS ('S' icon appears) if data fails.
    *   Throttle the network on the receiver's device (or turn off data completely) and ensure SMS messages are received and displayed in-app.
    *   Test sending messages while completely offline; they should be queued and sent when connectivity returns.

## Building the APK

1.  **Navigate to Project Root:** Open your terminal and navigate to the `ultra_light_app` directory.
2.  **Get Dependencies:** Run `flutter pub get`.
3.  **Build APK:** Run `flutter build apk --release`.
    *   The signed APK will be located in `build/app/outputs/flutter/apk/app-release.apk`.

**Note:** Before building, ensure you have configured Firebase for your project and updated the MQTT broker address in `mqtt_service.dart`.

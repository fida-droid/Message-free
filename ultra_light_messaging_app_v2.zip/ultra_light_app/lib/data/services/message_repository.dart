import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:ultra_light_app/data/models/message_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MessageRepository with ChangeNotifier {
  final FirebaseDatabase _database = FirebaseDatabase.instance;
  final List<MessageModel> _messages = [];
  String? _currentUserPhone;

  List<MessageModel> get messages => _messages;

  MessageRepository() {
    _init();
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    _currentUserPhone = prefs.getString('phone_number');
    if (_currentUserPhone != null) {
      _listenForMessages();
    }
  }

  void _listenForMessages() {
    _database.ref('messages/$_currentUserPhone').onChildAdded.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>;
      final message = MessageModel.fromMap(Map<String, dynamic>.from(data), false);
      
      if (!_messages.any((m) => m.id == message.id)) {
        _messages.add(message);
        notifyListeners();
      }
    });
  }

  Future<void> saveMessage(MessageModel message) async {
    _messages.add(message);
    notifyListeners();
    
    // In a real app, you'd also save to local SQLite/Hive here
  }

  Future<void> updateMessageStatus(String messageId, MessageStatus status) async {
    final index = _messages.indexWhere((m) => m.id == messageId);
    if (index != -1) {
      _messages[index] = _messages[index].copyWith(status: status);
      notifyListeners();
    }
  }

  List<MessageModel> getChatMessages(String otherPhone) {
    return _messages.where((m) => 
      (m.senderPhone == otherPhone && m.recipientPhone == _currentUserPhone) ||
      (m.senderPhone == _currentUserPhone && m.recipientPhone == otherPhone)
    ).toList()..sort((a, b) => a.timestamp.compareTo(b.timestamp));
  }
}

import 'dart:convert';

enum MessageStatus { pending, sentData, sentSms, delivered, failed }

class MessageModel {
  final String id;
  final String senderPhone;
  final String recipientPhone;
  final String content;
  final DateTime timestamp;
  final MessageStatus status;
  final bool isMe;

  MessageModel({
    required this.id,
    required this.senderPhone,
    required this.recipientPhone,
    required this.content,
    required this.timestamp,
    required this.status,
    required this.isMe,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'f': senderPhone,
      't': recipientPhone,
      'm': content,
      'ts': timestamp.millisecondsSinceEpoch,
      's': status.index,
    };
  }

  factory MessageModel.fromMap(Map<String, dynamic> map, bool isMe) {
    return MessageModel(
      id: map['id'] ?? '',
      senderPhone: map['f'] ?? '',
      recipientPhone: map['t'] ?? '',
      content: map['m'] ?? '',
      timestamp: DateTime.fromMillisecondsSinceEpoch(map['ts'] ?? DateTime.now().millisecondsSinceEpoch),
      status: MessageStatus.values[map['s'] ?? 0],
      isMe: isMe,
    );
  }

  String toJson() => json.encode(toMap());

  MessageModel copyWith({
    MessageStatus? status,
  }) {
    return MessageModel(
      id: id,
      senderPhone: senderPhone,
      recipientPhone: recipientPhone,
      content: content,
      timestamp: timestamp,
      status: status ?? this.status,
      isMe: isMe,
    );
  }
}

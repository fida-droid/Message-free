import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ultra_light_app/data/services/message_repository.dart';
import 'package:ultra_light_app/messaging/mqtt_service.dart';
import 'package:ultra_light_app/screens/chat/chat_screen.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repository = context.watch<MessageRepository>();
    final mqttService = context.watch<MqttService>();
    
    // Group messages by contact
    final contacts = <String>{};
    for (var m in repository.messages) {
      contacts.add(m.isMe ? m.recipientPhone : m.senderPhone);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Messages'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                mqttService.connectionState == MqttConnectionState.connected 
                  ? 'Online' : 'Offline',
                style: TextStyle(
                  color: mqttService.connectionState == MqttConnectionState.connected 
                    ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          final contact = contacts.elementAt(index);
          return ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(contact),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChatScreen(recipientPhone: contact)),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showNewChatDialog(context),
        child: const Icon(Icons.message),
      ),
    );
  }

  void _showNewChatDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('New Chat'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Phone Number'),
          keyboardType: TextInputType.phone,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ChatScreen(recipientPhone: controller.text)),
                );
              }
            },
            child: const Text('Start'),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ultra_light_app/data/models/message_model.dart';
import 'package:ultra_light_app/data/services/message_repository.dart';
import 'package:ultra_light_app/messaging/message_manager.dart';
import 'package:intl/intl.dart';

class ChatScreen extends StatefulWidget {
  final String recipientPhone;

  const ChatScreen({super.key, required this.recipientPhone});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  void _sendMessage() {
    if (_controller.text.isEmpty) return;
    
    final manager = context.read<MessageManager>();
    manager.sendMessage(widget.recipientPhone, _controller.text);
    _controller.clear();
    
    // Scroll to bottom
    Future.delayed(const Duration(milliseconds: 100), () {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final repository = context.watch<MessageRepository>();
    final messages = repository.getChatMessages(widget.recipientPhone);

    return Scaffold(
      appBar: AppBar(title: Text(widget.recipientPhone)),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return _MessageBubble(message: message);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'Type a message...',
                      border: OutlineInputBorder(),
                    ),
                    maxLength: 160,
                  ),
                ),
                IconButton(
                  onPressed: _sendMessage,
                  icon: const Icon(Icons.send),
                  color: Colors.green,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final MessageModel message;

  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: message.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: message.isMe ? Colors.green[100] : Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(message.content),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  DateFormat('HH:mm').format(message.timestamp),
                  style: const TextStyle(fontSize: 10, color: Colors.grey),
                ),
                if (message.isMe) ...[
                  const SizedBox(width: 4),
                  _getStatusIcon(message.status),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _getStatusIcon(MessageStatus status) {
    switch (status) {
      case MessageStatus.pending:
        return const Icon(Icons.access_time, size: 12, color: Colors.grey);
      case MessageStatus.sentData:
        return const Text('D', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.blue));
      case MessageStatus.sentSms:
        return const Text('S', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.orange));
      case MessageStatus.delivered:
        return const Icon(Icons.done_all, size: 12, color: Colors.green);
      case MessageStatus.failed:
        return const Icon(Icons.error_outline, size: 12, color: Colors.red);
    }
  }
}

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:ultra_light_app/messaging/mqtt_service.dart';
import 'package:ultra_light_app/messaging/sms_service.dart';
import 'package:ultra_light_app/messaging/message_manager.dart';
import 'package:ultra_light_app/data/services/message_repository.dart';
import 'package:ultra_light_app/services/background_service.dart';
import 'package:ultra_light_app/screens/auth/login_screen.dart';
import 'package:ultra_light_app/screens/chat/chat_list_screen.dart';
import 'package:ultra_light_app/l10n/app_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await initializeBackgroundService();
  
  final mqttService = MqttService();
  final smsService = SmsService();
  final repository = MessageRepository();
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: mqttService),
        ChangeNotifierProvider.value(value: smsService),
        ChangeNotifierProvider.value(value: repository),
        ChangeNotifierProxyProvider3<MqttService, SmsService, MessageRepository, MessageManager>(
          create: (context) => MessageManager(
            mqttService: mqttService,
            smsService: smsService,
            repository: repository,
          ),
          update: (context, mqtt, sms, repo, manager) => manager ?? MessageManager(
            mqttService: mqtt,
            smsService: sms,
            repository: repo,
          ),
        ),
      ],
      child: const UltraLightApp(),
    ),
  );
}

class UltraLightApp extends StatefulWidget {
  const UltraLightApp({super.key});

  @override
  State<UltraLightApp> createState() => _UltraLightAppState();
}

class _UltraLightAppState extends State<UltraLightApp> {
  bool _isLoggedIn = false;

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  Future<void> _checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isLoggedIn = prefs.getString('phone_number') != null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ultra-Light Messaging',
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
      ),
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', ''),
        Locale('ur', ''),
      ],
      home: _isLoggedIn ? const ChatListScreen() : const LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

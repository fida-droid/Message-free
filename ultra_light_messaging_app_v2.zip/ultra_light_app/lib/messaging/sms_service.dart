import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:telephony/telephony.dart';

class SmsService with ChangeNotifier {
  final Telephony telephony = Telephony.instance;
  final StreamController<Map<String, dynamic>> _smsStreamController = StreamController.broadcast();

  Stream<Map<String, dynamic>> get smsStream => _smsStreamController.stream;

  SmsService() {
    _initSmsListener();
  }

  void _initSmsListener() {
    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        _processIncomingSms(message);
      },
      listenInBackground: true,
      onBackgroundMessage: backGroundMessageHandler,
    );
  }

  void _processIncomingSms(SmsMessage message) {
    final body = message.body;
    if (body != null && body.startsWith('{') && body.endsWith('}')) {
      try {
        final Map<String, dynamic> data = jsonDecode(body);
        // Verify it's a message for our app
        if (data.containsKey('f') && data.containsKey('m') && data.containsKey('id')) {
          _smsStreamController.add(data);
        }
      } catch (e) {
        debugPrint('Error decoding SMS JSON: $e');
      }
    }
  }

  Future<bool> sendSmsMessage(String recipientPhone, String message, String messageId, String senderPhone) async {
    final payload = jsonEncode({
      'f': senderPhone,
      't': recipientPhone,
      'm': message,
      'id': messageId,
    });

    try {
      await telephony.sendSms(
        to: recipientPhone,
        message: payload,
      );
      return true;
    } catch (e) {
      debugPrint('SMS send failed: $e');
      return false;
    }
  }
}

@pragma('vm:entry-point')
void backGroundMessageHandler(SmsMessage message) {
  // Handle background SMS if needed
  // This is called when the app is in the background or terminated
  debugPrint('Background SMS received: ${message.body}');
}

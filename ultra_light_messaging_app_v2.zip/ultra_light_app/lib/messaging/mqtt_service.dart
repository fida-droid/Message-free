import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

enum MqttConnectionState { connected, disconnected, connecting }

class MqttService with ChangeNotifier {
  MqttServerClient? _client;
  MqttConnectionState _connectionState = MqttConnectionState.disconnected;
  final StreamController<Map<String, dynamic>> _messageStreamController = StreamController.broadcast();

  MqttConnectionState get connectionState => _connectionState;
  Stream<Map<String, dynamic>> get messageStream => _messageStreamController.stream;

  Future<void> connect() async {
    if (_connectionState == MqttConnectionState.connected) return;

    final prefs = await SharedPreferences.getInstance();
    final phoneNumber = prefs.getString('phone_number');
    final token = prefs.getString('auth_token');

    if (phoneNumber == null || token == null) return;

    _connectionState = MqttConnectionState.connecting;
    notifyListeners();

    // Replace with your actual MQTT broker address
    _client = MqttServerClient('your-mqtt-broker-address.com', 'flutter_client_${const Uuid().v4()}');
    _client!.port = 443;
    _client!.keepAlivePeriod = 60;
    _client!.onDisconnected = _onDisconnected;
    _client!.onConnected = _onConnected;
    _client!.onSubscribed = _onSubscribed;
    _client!.logging(on: false);

    final connMessage = MqttConnectMessage()
        .withClientIdentifier('flutter_client_${const Uuid().v4()}')
        .authenticateAs(phoneNumber, token)
        .startClean()
        .withWillQos(MqttQos.atLeastOnce);

    _client!.connectionMessage = connMessage;

    try {
      await _client!.connect();
    } catch (e) {
      debugPrint('MQTT connection failed: $e');
      _disconnect();
    }
  }

  void _onConnected() {
    _connectionState = MqttConnectionState.connected;
    notifyListeners();
    debugPrint('MQTT Connected');
    
    // Subscribe to user's topic
    _subscribeToUserTopic();
    
    _client!.updates!.listen((List<MqttReceivedMessage<MqttMessage>> c) {
      final MqttPublishMessage recMess = c[0].payload as MqttPublishMessage;
      final pt = MqttPublishPayload.bytesToStringAsString(recMess.payload.message);
      
      try {
        final Map<String, dynamic> data = jsonDecode(pt);
        _messageStreamController.add(data);
      } catch (e) {
        debugPrint('Error decoding MQTT message: $e');
      }
    });
  }

  void _onDisconnected() {
    _connectionState = MqttConnectionState.disconnected;
    notifyListeners();
    debugPrint('MQTT Disconnected');
  }

  void _onSubscribed(String topic) {
    debugPrint('Subscribed to topic: $topic');
  }

  void _disconnect() {
    _client?.disconnect();
    _onDisconnected();
  }

  Future<void> _subscribeToUserTopic() async {
    final prefs = await SharedPreferences.getInstance();
    final phoneNumber = prefs.getString('phone_number');
    if (phoneNumber != null) {
      _client?.subscribe('chat/$phoneNumber', MqttQos.atLeastOnce);
    }
  }

  Future<bool> publishMessage(String recipientPhone, String message, String messageId) async {
    if (_connectionState != MqttConnectionState.connected) return false;

    final prefs = await SharedPreferences.getInstance();
    final senderPhone = prefs.getString('phone_number');

    final payload = jsonEncode({
      'f': senderPhone,
      't': recipientPhone,
      'm': message,
      'id': messageId,
    });

    final builder = MqttClientPayloadBuilder();
    builder.addString(payload);

    try {
      _client!.publishMessage('chat/$recipientPhone', MqttQos.atLeastOnce, builder.payload!);
      return true;
    } catch (e) {
      debugPrint('MQTT publish failed: $e');
      return false;
    }
  }
}

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:ultra_light_app/data/models/message_model.dart';
import 'package:ultra_light_app/data/services/message_repository.dart';
import 'package:ultra_light_app/messaging/mqtt_service.dart';
import 'package:ultra_light_app/messaging/sms_service.dart';
import 'package:uuid/uuid.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MessageManager with ChangeNotifier {
  final MqttService mqttService;
  final SmsService smsService;
  final MessageRepository repository;

  MessageManager({
    required this.mqttService,
    required this.smsService,
    required this.repository,
  }) {
    _initListeners();
  }

  void _initListeners() {
    mqttService.messageStream.listen(_handleIncomingMessage);
    smsService.smsStream.listen(_handleIncomingMessage);
  }

  void _handleIncomingMessage(Map<String, dynamic> data) {
    final message = MessageModel.fromMap(data, false);
    repository.saveMessage(message);
  }

  Future<void> sendMessage(String recipientPhone, String content) async {
    final prefs = await SharedPreferences.getInstance();
    final senderPhone = prefs.getString('phone_number') ?? '';
    final messageId = const Uuid().v4();
    
    final message = MessageModel(
      id: messageId,
      senderPhone: senderPhone,
      recipientPhone: recipientPhone,
      content: content,
      timestamp: DateTime.now(),
      status: MessageStatus.pending,
      isMe: true,
    );

    await repository.saveMessage(message);

    // Try MQTT first
    bool mqttSuccess = await mqttService.publishMessage(recipientPhone, content, messageId);
    
    if (mqttSuccess) {
      await repository.updateMessageStatus(messageId, MessageStatus.sentData);
    } else {
      // Wait 5 seconds for potential reconnection or ACK, then fallback to SMS
      await Future.delayed(const Duration(seconds: 5));
      
      // Re-check MQTT status or if message was already acknowledged (simplified here)
      if (mqttService.connectionState != MqttConnectionState.connected) {
        bool smsSuccess = await smsService.sendSmsMessage(recipientPhone, content, messageId, senderPhone);
        if (smsSuccess) {
          await repository.updateMessageStatus(messageId, MessageStatus.sentSms);
        } else {
          await repository.updateMessageStatus(messageId, MessageStatus.failed);
        }
      }
    }
  }
}

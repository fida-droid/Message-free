const mosca = require('mosca');
const admin = require('firebase-admin');
require('dotenv').config();

// Initialize Firebase Admin (Requires serviceAccountKey.json)
// const serviceAccount = require("../serviceAccountKey.json");
// admin.initializeApp({
//   credential: admin.credential.cert(serviceAccount),
//   databaseURL: process.env.FIREBASE_DATABASE_URL
// });

const settings = {
  port: 1883,
};

const server = new mosca.Server(settings);

server.on('clientConnected', function(client) {
    console.log('client connected', client.id);
});

// Authentication logic
server.authenticate = function(client, username, password, callback) {
  console.log('Authenticating client:', username);
  
  // In production, verify the token against Firebase or your DB
  // For MVP, we'll accept any username/password for demonstration
  // if (username && password) {
  //   callback(null, true);
  // } else {
  //   callback(null, false);
  // }
  
  callback(null, true);
};

// Authorization logic
server.authorizePublish = function(client, topic, payload, callback) {
  // Ensure user can only publish to their own topic or recipient's topic
  // For MVP, allow all
  callback(null, true);
};

server.authorizeSubscribe = function(client, topic, callback) {
  // Ensure user can only subscribe to their own topic 'chat/phone_number'
  // const phoneNumber = client.id.split('_')[2]; // Example extraction
  // if (topic === `chat/${phoneNumber}`) {
  //   callback(null, true);
  // } else {
  //   callback(null, false);
  // }
  
  callback(null, true);
};

server.on('ready', setup);

function setup() {
  console.log('Mosca server is up and running on port 1883');
}
